<!-- https://github.com/DenverCoder1/readme-typing-svg/ -->
<svg xmlns='http://www.w3.org/2000/svg'
    xmlns:xlink='http://www.w3.org/1999/xlink'
    viewBox='0 0 400 50'
    width='400px' height='50px'>

    <text font-family='monospace' fill='#c00' font-size='18'
        y="50%" x='50%' dominant-baseline='middle' text-anchor='middle'>
        <?= $message . "\n" ?>
    </text>
</svg>
